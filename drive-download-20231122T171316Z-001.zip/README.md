C# Chatting using ULTRAmsg API

# Downloads

Tunneling is required.  Download ngrok(https://ngrok.com/download).

# Set the instance ID and token
Set the instance ID and token in appsettings.json file.

# Starting ngrok 
Run ngrok for MAC or Windows:

ngrok http https://localhost:6000


# receive messages and command processing
This is all you need to receive and read messages from users, and then respond to them.

