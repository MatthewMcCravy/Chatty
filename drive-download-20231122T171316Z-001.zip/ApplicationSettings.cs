﻿namespace Chatty
{
    public class AppSettings
    {
        public string InstanceId { get; set; } = null!;
        public string Token { get; set; } = null!;
    }
}
